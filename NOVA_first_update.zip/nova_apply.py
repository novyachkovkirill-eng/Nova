#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def replace_once(path, old, new, label):
    p = ROOT / path
    if not p.exists():
        raise SystemExit(f"[NOVA] Missing file: {path}")
    data = p.read_text(encoding="utf-8")
    count = data.count(old)
    if count != 1:
        raise SystemExit(f"[NOVA] Expected one match for {label}, found {count} in {path}")
    p.write_text(data.replace(old, new, 1), encoding="utf-8")
    print(f"[NOVA] Patched: {path} ({label})")

replace_once("TMessagesProj/src/main/res/values/strings.xml", '<string name="AppName">Telegram</string>', '<string name="AppName">NOVA</string>', "English app name")
replace_once("TMessagesProj/src/main/res/values/strings.xml", '<string name="AppNameBeta">Telegram Beta</string>', '<string name="AppNameBeta">NOVA</string>', "English beta app name")
replace_once("TMessagesProj/src/main/res/values/strings.xml", '    <string name="LanguageCode">en</string>', """    <string name="LanguageCode">en</string>
    <string name="NovaSection">NOVA</string>
    <string name="NovaSettings">NOVA settings</string>
    <string name="NovaSettingsInfo">Preview experimental NOVA options</string>
    <string name="NovaPreview">Preview options</string>
    <string name="NovaDemoAnimations">Enable NOVA animations (demo)</string>
    <string name="NovaDemoExperimental">Show experimental options (demo)</string>
    <string name="NovaDemoHint">These switches are visual test controls. They do not change Telegram behavior yet.</string>
    <string name="NovaAbout">About NOVA</string>
    <string name="NovaAboutText">NOVA is an independent Telegram-based client. This is an early test build.</string>""", "English NOVA strings")
replace_once("TMessagesProj/src/main/res/values-ru/strings.xml", '<string name="AppName">Telegram</string>', '<string name="AppName">NOVA</string>', "Russian app name")
replace_once("TMessagesProj/src/main/res/values-ru/strings.xml", '<string name="AppNameBeta">Telegram Beta</string>', '<string name="AppNameBeta">NOVA</string>', "Russian beta app name")
replace_once("TMessagesProj/src/main/res/values-ru/strings.xml", '    <string name="LanguageCode">ru</string>', """    <string name="LanguageCode">ru</string>
    <string name="NovaSection">NOVA</string>
    <string name="NovaSettings">Настройки NOVA</string>
    <string name="NovaSettingsInfo">Предварительный просмотр экспериментальных настроек NOVA</string>
    <string name="NovaPreview">Параметры демо</string>
    <string name="NovaDemoAnimations">Анимации NOVA (демо)</string>
    <string name="NovaDemoExperimental">Показывать экспериментальные функции (демо)</string>
    <string name="NovaDemoHint">Эти переключатели нужны для проверки интерфейса. Пока они не меняют работу Telegram.</string>
    <string name="NovaAbout">О NOVA</string>
    <string name="NovaAboutText">NOVA — независимый клиент на базе Telegram. Это ранняя тестовая сборка.</string>""", "Russian NOVA strings")
replace_once("TMessagesProj/src/main/java/org/telegram/ui/SettingsActivity.java", '        items.add(UItem.asHeader(getString(R.string.SettingsHelp)));', """        items.add(UItem.asShadow(null));
        items.add(UItem.asHeader(getString(R.string.NovaSection)));
        items.add(SettingCell.Factory.of(28, 0xFF8B5CF6, 0xFF4169E1, R.drawable.settings_language, getString(R.string.NovaSettings), getString(R.string.NovaSettingsInfo)));
        items.add(UItem.asShadow(null));

        items.add(UItem.asHeader(getString(R.string.SettingsHelp)));""", "NOVA settings row")
replace_once("TMessagesProj/src/main/java/org/telegram/ui/SettingsActivity.java", """            case 27: {
                presentFragment(new HeaderSettingsActivity());
                break;
            }""", """            case 27: {
                presentFragment(new HeaderSettingsActivity());
                break;
            }
            case 28: {
                presentSettingFragment(new NovaSettingsActivity());
                break;
            }""", "NOVA settings navigation")
replace_once("TMessagesProj/config/debug/AndroidManifest_SDK23.xml", 'android:icon="@mipmap/ic_launcher"', 'android:icon="@drawable/nova_launcher"', "NOVA launcher icon")
replace_once("TMessagesProj/config/debug/AndroidManifest_SDK23.xml", 'android:roundIcon="@mipmap/ic_launcher_round"', 'android:roundIcon="@drawable/nova_launcher"', "NOVA round launcher icon")

activity = """package org.telegram.ui;

import android.content.Context;
import android.view.View;

import org.telegram.messenger.R;
import org.telegram.messenger.LocaleController;
import org.telegram.ui.Components.UItem;
import org.telegram.ui.Components.UniversalAdapter;
import org.telegram.ui.Components.UniversalFragment;
import org.telegram.ui.Components.RecyclerListView;

import java.util.ArrayList;

/** NOVA's first settings preview. The switches are intentionally demo-only. */
public class NovaSettingsActivity extends UniversalFragment {
    private boolean demoAnimations = true;
    private boolean demoExperimental = false;

    @Override
    protected boolean useSimpleActionBar() {
        return true;
    }

    @Override
    public View createView(Context context) {
        setHasOwnBackground(true);
        fragmentView = super.createView(context);
        listView.setSections();
        listView.setSectionsDrawBackground(true);
        return fragmentView;
    }

    @Override
    protected RecyclerListView getListViewForSimpleGlass() {
        return listView;
    }

    @Override
    protected CharSequence getTitle() {
        return LocaleController.getString(R.string.NovaSettings);
    }

    @Override
    protected void fillItems(ArrayList<UItem> items, UniversalAdapter adapter) {
        items.add(UItem.asHeader(LocaleController.getString(R.string.NovaPreview)));
        items.add(UItem.asCheck(1, LocaleController.getString(R.string.NovaDemoAnimations)).setChecked(demoAnimations));
        items.add(UItem.asCheck(2, LocaleController.getString(R.string.NovaDemoExperimental)).setChecked(demoExperimental));
        items.add(UItem.asShadow(LocaleController.getString(R.string.NovaDemoHint)));
        items.add(UItem.asHeader(LocaleController.getString(R.string.NovaAbout)));
        items.add(UItem.asShadow(LocaleController.getString(R.string.NovaAboutText)));
    }

    @Override
    protected void onClick(UItem item, View view, int position, float x, float y) {
        if (item.id == 1) {
            demoAnimations = !demoAnimations;
        } else if (item.id == 2) {
            demoExperimental = !demoExperimental;
        } else {
            return;
        }
        listView.adapter.update(true);
    }

    @Override
    protected boolean onLongClick(UItem item, View view, int position, float x, float y) {
        return false;
    }
}
"""
